# AgriVision AI

A standalone demo website for **AI based smart crop disease detection and farming assistant**.

## Features

- Login page for farmers
- Plant image upload and preview
- Demo disease detection results by crop and symptom
- Browser-side ML-style image analysis using canvas pixel features
- AI image signals for leaf coverage, yellowing, spot index, and image quality
- Treatment, prevention, and care guidance
- Farm location, field size, crop stage, and weather advisory cards
- Saved scan history with field risk summary
- Downloadable crop health report and copyable advice
- Farming assistant chat for irrigation, fertilizer, pest, soil, and weather questions
- Quick assistant prompts for rain disease care, fertilizer, and pest control
- 7-day farm care checklist with saved progress
- Spray safety guidance

## Run

Open `index.html` in a browser. No server or installation is required.

## Install As An App

For install/offline app mode, open the folder in VS Code and run it with the Live Server extension. Then open the local URL, usually `http://127.0.0.1:5500/index.html`, and click **Install app** when the button appears.

The app includes:

- `manifest.webmanifest` for install metadata
- `service-worker.js` for offline caching
- app icons in `assets/`

This is a front-end prototype. A real AI detector would need a trained model or backend API connected to the upload flow.
